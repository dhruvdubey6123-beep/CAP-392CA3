/*
 * Q.NO: 13
 * Question: Find the Index of the First Occurrence in a String
 * LeetCode ID: 28
 * Problem Link: https://leetcode.com/problems/find-the-index-of-the-first-occurrence-in-a-string/
 *
 * Solution:
 */

class Solution {
    public int strStr(String haystack, String needle) {
        if (needle.length() == 0) return 0;
        for (int i = 0; i <= haystack.length() - needle.length(); i++) {
            int j = 0;
            while (j < needle.length() && haystack.charAt(i + j) == needle.charAt(j)) j++;
            if (j == needle.length()) return i;
        }
        return -1;
    }
}
