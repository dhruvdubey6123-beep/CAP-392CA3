/*
 * Q.NO: 16
 * Question: Design Linked List
 * LeetCode ID: 707
 * Problem Link: https://leetcode.com/problems/design-linked-list/
 *
 * Solution:
 */

class MyLinkedList {
    private class Node {
        int val;
        Node next;
        Node(int val) { this.val = val; }
    }
    private Node head;
    private int size;
    public MyLinkedList() {
        head = new Node(0);
        size = 0;
    }
    public int get(int index) {
        if (index < 0 || index >= size) return -1;
        Node current = head.next;
        for (int i = 0; i < index; i++) current = current.next;
        return current.val;
    }
    public void addAtHead(int val) { addAtIndex(0, val); }
    public void addAtTail(int val) { addAtIndex(size, val); }
    public void addAtIndex(int index, int val) {
        if (index < 0) index = 0;
        if (index > size) return;
        Node current = head;
        for (int i = 0; i < index; i++) current = current.next;
        Node newNode = new Node(val);
        newNode.next = current.next;
        current.next = newNode;
        size++;
    }
    public void deleteAtIndex(int index) {
        if (index < 0 || index >= size) return;
        Node current = head;
        for (int i = 0; i < index; i++) current = current.next;
        current.next = current.next.next;
        size--;
    }
}
